﻿namespace LibraryManagement.UI;

internal static class ConsoleEntry { public static void Main(string[] args) => LibraryConsole.Run(); }
